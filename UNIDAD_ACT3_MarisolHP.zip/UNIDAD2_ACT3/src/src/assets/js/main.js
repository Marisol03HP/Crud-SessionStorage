function checkLogin() {
    if (sessionStorage.getItem('auth') !== 'true') {
        mostrarMensaje("Acceso denegado. Inicia sesión.", "danger");
        window.location.href = 'login.html';
    }
}

function validarCamposNumericos() {
    const campos = ["idProducto", "precio"];
    let valido = true;

    campos.forEach(campoId => {
        const campo = document.getElementById(campoId);
        if (campo && parseFloat(campo.value) < 0) {
            campo.classList.add("is-invalid");
            mostrarMensaje(`❌ El campo ${campo.placeholder} no puede ser negativo.`, "danger");
            valido = false;
        } else {
            campo.classList.remove("is-invalid");
        }
    });

    return valido;
}


["idProducto", "precio"].forEach(campoId => {
    const campo = document.getElementById(campoId);
    campo?.addEventListener("input", function () {
        if (parseFloat(this.value) < 0) {
            this.value = "";
            mostrarMensaje(`❌ El campo ${this.placeholder} no puede ser negativo.`, "danger");
        }
    });
});

document.getElementById("idProducto").addEventListener("input", function () {
    this.classList.remove("is-invalid");
    document.getElementById("id-error").style.display = "none";
});

document.getElementById('productForm').addEventListener('submit', function (e) {
    e.preventDefault();


    if (!this.checkValidity()) {
        this.classList.add('was-validated');
        mostrarMensaje("⚠️ Por favor, completa todos los campos requeridos.", "danger");
        return;
    }


    function actualizarLocalStorage(productos) {
        localStorage.setItem("productos", JSON.stringify(productos));
    }

    function agregarProducto(nuevoProducto) {
        let productos = JSON.parse(localStorage.getItem("productos")) || [];
        productos.push(nuevoProducto);
        actualizarLocalStorage(productos);
    }

    function editarProducto(id, productoEditado) {
        let productos = JSON.parse(localStorage.getItem("productos")) || [];
        productos = productos.map(producto => producto.id === id ? productoEditado : producto);
        actualizarLocalStorage(productos);
    }

    function eliminarProducto(id) {
        let productos = JSON.parse(localStorage.getItem("productos")) || [];
        productos = productos.filter(producto => producto.id !== id);
        actualizarLocalStorage(productos);
    }


    const nombre = document.getElementById('nombre').value;
    const talla = document.getElementById('talla').value;
    const precio = document.getElementById('precio').value;
    const fecha = document.getElementById('fecha').value;
    const genero = document.querySelector('input[name="genero"]:checked')?.value || '';
    const disponible = document.getElementById('disponible').checked ? 'Sí' : 'No';
    const categoria = document.getElementById('categoria').value;
    const descripcion = document.getElementById('descripcion').value;


    let idInput = document.getElementById("idProducto");
    let id = idInput.value.trim();
    let idError = document.getElementById("id-error");
    let idDuplicado = false;

    if (id !== "") {
        const filas = document.querySelectorAll("#tablaProductos tbody tr");
        for (let fila of filas) {
            const idExistente = fila.children[0].textContent.trim();
            if (idExistente === id) {
                idDuplicado = true;
                break;
            }
        }

        if (idDuplicado) {
            mostrarMensaje("🔍 Producto encontrado: ya está en la tabla.", "warning");
            return;
        } else {

            idInput.classList.remove("is-invalid");
            idError.style.display = "none";
        }
    }

    const tabla = document.getElementById('tablaProductos');
    tabla.classList.remove('hidden');

    const tbody = document.getElementById('tbodyProductos');
    const fila = document.createElement('tr');
    fila.innerHTML = `
    <td>${id}</td>
    <td>${nombre}</td>
    <td>${talla}</td>
    <td>${precio}</td>
    <td>${fecha}</td>
    <td>${genero}</td>
    <td>${disponible}</td>
    <td>${categoria}</td>
<td>${descripcion}</td>

    <td>
        <button class="btn btn-warning btn-sm" onclick="editar(this)">✏️</button>
        <button class="btn btn-success btn-sm" onclick="guardar(this)">💾</button>
        <button class="btn btn-secondary btn-sm" onclick="cancelar(this)">❌</button>
        <button class="btn btn-danger btn-sm" onclick="eliminar(this)">🗑️</button>
    </td>`;
    tbody.appendChild(fila);

    guardarProductosEnSession();
    tbody.appendChild(fila);
    guardarProductosEnSession();
    document.getElementById('tablaProductos').classList.remove('hidden');
    document.getElementById('btnBorrarTodo').classList.remove('d-none');
    mostrarMensaje("✅ Producto agregado correctamente.", "success");


    const form = document.getElementById('productForm');
    form.reset();
    form.classList.remove('was-validated');
    document.querySelectorAll('input[name="genero"]').forEach(r => r.checked = false);
    document.getElementById('disponible').checked = false
});

function editar(btn) {
    const celdas = btn.closest('tr').children;
    for (let i = 0; i < 8; i++) {
        const valorActual = celdas[i].innerText.trim();
        celdas[i].innerHTML = `<input class="form-control w-100" value="${valorActual}">`;
    }
}

function guardar(btn) {
    const fila = btn.closest('tr');
    const celdas = fila.children;
    const nuevoID = celdas[0].querySelector('input')?.value.trim();

    const filas = document.querySelectorAll("#tablaProductos tbody tr");
    for (let otraFila of filas) {
        if (otraFila !== fila) {
            const idExistente = otraFila.children[0];
            const valorExistente = idExistente.querySelector('input')
                ? idExistente.querySelector('input').value.trim()
                : idExistente.textContent.trim();
            if (valorExistente === nuevoID) {
                mostrarMensaje("❌ El ID ya existe. Ingresa uno diferente.", "danger");
                return;
            }
        }
    }

    for (let i = 0; i < 8; i++) {
        const input = celdas[i].querySelector('input');
        if (input) {
            celdas[i].textContent = input.value;
        }
    }
    guardarProductosEnSession();
    mostrarMensaje("✅ Datos actualizados correctamente.", "primary");
}

function cancelar(btn) {
    const fila = btn.closest('tr');
    const id = fila.children[0].textContent.trim();

    mostrarConfirmacion("¿Estás seguro de cancelar este producto?", () => {
        fila.remove();
        eliminarProductoDeLocalStorage(id);
        verificarTablaVacia();
        mostrarMensaje("❗ Acción cancelada. El producto fue eliminado.", "warning");
    });
}



function eliminar(btn) {
    const fila = btn.closest('tr');
    const idEliminar = fila.children[0].textContent.trim();

    mostrarConfirmacion("¿Deseas eliminar este registro?", () => {
        fila.remove();
        eliminarProductoDeLocalStorage(idEliminar);
        verificarTablaVacia();
        mostrarMensaje("🗑️ Registro eliminado correctamente.", "danger");
    });

}

function verificarTablaVacia() {
    const tabla = document.getElementById('tbodyProductos');
    if (!tabla.children.length) {
        document.getElementById('tablaProductos').classList.add('hidden');
        document.getElementById('btnBorrarTodo').classList.add('d-none');
        mostrarConfirmacion("No hay productos. ¿Deseas borrar la base de datos?", () => {
            mostrarMensaje("Base de datos borrada.", "warning");
        });
    }
}

function mostrarConfirmacion(mensaje, onConfirmar) {
    const contenedor = document.getElementById('mensaje');

    contenedor.className = 'alert alert-warning d-flex justify-content-between align-items-center';
    contenedor.innerHTML = `
        <span>${mensaje}</span>
        <div>
            <button class="btn btn-sm btn-danger me-2" id="confirmarSi">Sí</button>
            <button class="btn btn-sm btn-secondary" id="confirmarNo">No</button>
        </div>
    `;
    contenedor.classList.remove('d-none');


    document.getElementById('confirmarSi').onclick = () => {
        contenedor.classList.add('d-none');
        contenedor.innerHTML = "";
        onConfirmar();
    };

    document.getElementById('confirmarNo').onclick = () => {
        contenedor.classList.add('d-none');
        contenedor.innerHTML = "";
    };

}

document.getElementById('btnBorrarTodo').addEventListener('click', () => {
    document.getElementById('confirmarEliminarTodo').classList.remove('d-none');
});

function confirmarBorrado() {
    const tabla = document.querySelector('#tablaProductos tbody');
    tabla.innerHTML = '';
    document.getElementById('tablaProductos').classList.add('hidden');
    document.getElementById('confirmarEliminarTodo').classList.add('d-none');
    localStorage.removeItem('productos');
    mostrarMensaje('La base de datos ha sido eliminada.', 'danger');
}

function cancelarBorrado() {
    document.getElementById('confirmarEliminarTodo').classList.add('d-none');
}

function mostrarMensaje(texto, tipo) {
    const div = document.getElementById('mensaje');
    div.textContent = texto;
    div.className = `mensaje-${tipo} mb-3 alert alert-${tipo}`;
    div.classList.remove('d-none');

    setTimeout(() => {
        div.classList.add('d-none');
    }, 6000);
}


document.getElementById('buscador').addEventListener('input', function () {
    const texto = this.value.toLowerCase();
    const filas = document.querySelectorAll("#tablaProductos tbody tr");
    let algunaVisible = false;

    if (!filas.length) {
        mostrarMensaje("La base de datos está vacía. No se puede buscar.", "warning");
        return;
    }

    filas.forEach(fila => {
        const contenido = fila.textContent.toLowerCase();
        const esCoincidente = contenido.includes(texto);
        fila.style.display = esCoincidente ? "" : "none";
        if (esCoincidente) algunaVisible = true;
    });

    const tabla = document.getElementById('tablaProductos');
    tabla.classList.toggle('hidden', !algunaVisible);

    if (!algunaVisible) {
        mostrarMensaje("🔍 No se encontró el producto .", "warning");
    } else {
        mostrarMensaje("✅ Producto encontrado.", "success");
    }
});


function cargarProductosDesdeLocalStorage() {
    const productosGuardados = JSON.parse(localStorage.getItem('productos')) || [];

    if (productosGuardados.length > 0) {
        const tabla = document.getElementById('tablaProductos');
        tabla.classList.remove('hidden');


        document.getElementById('tablaProductos').classList.remove('hidden');
        document.getElementById('btnBorrarTodo').classList.remove('d-none');

        const tbody = document.getElementById('tbodyProductos');
        tbody.innerHTML = '';

        productosGuardados.forEach(producto => {
            const fila = document.createElement('tr');
            fila.innerHTML = `
                <td>${producto.id}</td>
                <td>${producto.nombre}</td>
                <td>${producto.talla}</td>
                <td>${producto.precio}</td>
                <td>${producto.fecha}</td>
                <td>${producto.genero}</td>
                <td>${producto.disponible}</td>
                <td>${producto.categoria}</td>
                <td>${producto.descripcion}</td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="editar(this)">✏️</button>
                    <button class="btn btn-success btn-sm" onclick="guardar(this)">💾</button>
                    <button class="btn btn-secondary btn-sm" onclick="cancelar(this)">❌</button>
                    <button class="btn btn-danger btn-sm" onclick="eliminar(this)">🗑️</button>
                </td>`;
            tbody.appendChild(fila);

            guardarProductosEnSession();

            document.getElementById('tablaProductos').classList.remove('hidden');
            document.getElementById('btnBorrarTodo').classList.remove('d-none');
            mostrarMensaje("✅ Producto agregado correctamente.", "success");
        });
    }
}

function guardarProductosEnSession() {

    const filas = document.querySelectorAll("#tablaProductos tbody tr");
    const productos = [];

    filas.forEach(fila => {
        const celdas = fila.querySelectorAll('td');
        productos.push({
            id: celdas[0].textContent,
            nombre: celdas[1].textContent,
            talla: celdas[2].textContent,
            precio: celdas[3].textContent,
            fecha: celdas[4].textContent,
            genero: celdas[5].textContent,
            disponible: celdas[6].textContent,
            categoria: celdas[7].textContent,
            descripcion: celdas[8].textContent
        });
    });

    localStorage.setItem('productos', JSON.stringify(productos));
}
function eliminarProductoDeLocalStorage(id) {
    const productos = JSON.parse(localStorage.getItem('productos')) || [];
    const nuevosProductos = productos.filter(producto => producto.id !== id);
    localStorage.setItem('productos', JSON.stringify(nuevosProductos));
}



const form = document.getElementById('productForm');
if (form) {
    form.reset();
    form.classList.remove('was-validated');
}
const descripcion = document.getElementById('descripcion');
if (descripcion) {
    descripcion.value = "";
}


document.querySelectorAll('input[name="genero"]').forEach(r => r.checked = false);
document.getElementById('disponible').checked = false;

window.onload = () => {
    const mensaje = document.getElementById("mensaje");
    if (mensaje) mensaje.classList.add("d-none");
};
;

