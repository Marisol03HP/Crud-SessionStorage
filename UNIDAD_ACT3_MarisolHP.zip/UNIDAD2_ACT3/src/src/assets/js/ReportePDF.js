const { jsPDF } = window.jspdf;

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('btnreportePDF').addEventListener('click', async () => {
        try {
            const url = '../image/Playeras.webp';
            const datosImagen = await cargarImagen(url);

            const doc = new jsPDF({
                orientation: 'portrait',
                format: 'letter',
                unit: 'mm'
            });

            encabezado(doc, datosImagen);

            const productos = JSON.parse(localStorage.getItem("productos")) || [];

            const agrupaciones = {};
            const tipoReporte = document.getElementById('tipoReporte')?.value || "categoria";

            // Solo filtramos productos sin contar aún
            const productosFiltrados = productos.filter(p => {
                return true; // Aquí puedes aplicar filtros si deseas más adelante
            });

            let columnas = [];
            let cuerpoTabla = [];

            if (tipoReporte === "categoria") {
                columnas = ['ID', 'Nombre', 'Precio', 'Fecha', 'Género', 'Disponible', 'Categoría', 'Descripción'];
                cuerpoTabla = productosFiltrados.map(p => [
                    p.id, p.nombre, p.precio, p.fecha, p.genero,
                    p.disponible, p.categoria, p.descripcion
                ]);
            } else {
                columnas = ['ID', 'Nombre', 'Precio', 'Fecha', 'Género', 'Disponible', 'Talla', 'Descripción'];
                cuerpoTabla = productosFiltrados.map(p => [
                    p.id, p.nombre, p.precio, p.fecha, p.genero,
                    p.disponible, p.talla, p.descripcion
                ]);
            }



            doc.autoTable({
                startY: 50,
                head: [columnas],
                body: cuerpoTabla,

                body: cuerpoTabla,
                theme: 'grid',
                headStyles: {
                    fillColor: [255, 131, 51],
                    textColor: 255,
                    fontSize: 11,
                    fontStyle: 'bold'
                },
                bodyStyles: {
                    fontSize: 9,
                    textColor: [80, 80, 80]
                },
                didParseCell(data) {
                    if (data.section === 'body' && data.column.index === 3) {
                        const precio = parseFloat(data.cell.raw);
                        if (!isNaN(precio)) {
                            data.cell.text = "$" + precio.toFixed(2);
                        }
                    }
                }
            });

            // const tipoReporte = document.getElementById('tipoReporte')?.value || "categoria";

            // const agrupaciones = {};
            for (const p of productos) {
                const clave = tipoReporte === "categoria" ? p.categoria : p.talla;
                agrupaciones[clave] = (agrupaciones[clave] || 0) + 1;
            }

            if (Object.keys(agrupaciones).length > 0) {
                doc.addPage();
                encabezado(doc, datosImagen);

                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.setTextColor(40);
                doc.text(
                    tipoReporte === "categoria" ? "Gráfica: Recuento por Categoría" : "Gráfica: Recuento por Talla",
                    doc.internal.pageSize.getWidth() / 2,
                    30,
                    { align: "center" }
                );

                graficarBarras(doc, agrupaciones, 20, 120, 170, 80, 10);
            }

            const pageCount = doc.internal.getNumberOfPages();
            for (let i = 1; i <= pageCount; i++) {
                doc.setPage(i);
                doc.setFontSize(10);
                doc.setTextColor(100);
                doc.text(`Página ${i} de ${pageCount}`, doc.internal.pageSize.getWidth() / 2, doc.internal.pageSize.getHeight() - 10, { align: 'center' });
            }

            doc.save("Reporte_Productos.pdf");

        } catch (error) {
            console.error("Error al generar el PDF:", error);
        }
    });
});

function cargarImagen(urlImagen) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error("Fallo la carga de la imagen"));
        img.src = urlImagen;
    });
}

function encabezado(doc, datosImagen) {
    doc.setFont("times", "bold");
    doc.setFontSize(16);
    doc.setTextColor(255, 0, 255);
    doc.text("Reporte De Listado de Productos De Moda", doc.internal.pageSize.getWidth() / 2, 15, { align: "center" });
    doc.addImage(datosImagen, 'JPEG', 10, 5, 30, 30);
}

function graficarBarras(doc, data, x, yBase, width, maxHeight, spacing) {
    const keys = Object.keys(data);
    const max = Math.max(...Object.values(data));
    const barWidth = (width - spacing * (keys.length - 1)) / keys.length;

    let xActual = x;

    keys.forEach(key => {
        const valor = data[key];
        const altura = (valor / max) * maxHeight;
        const y = yBase - altura;

        const colores = {
            // Tallas
            "CH": [135, 206, 250],
            "MD": [144, 238, 144],
            "GD": [255, 182, 193],
            "XL": [255, 215, 0],
            "XXL": [218, 112, 214],

            "Blusas": [255, 0, 127],
            "Pantalones": [79, 51, 255],
            "Vestidos": [214, 51, 255],
            "Ropa deportiva": [51, 255, 133],
            "Ropa unisex": [144, 238, 144]
        };
        const color = colores[key] || [255, 200, 150];

        doc.setFillColor(...color);
        doc.rect(xActual, y, barWidth, altura, 'F');

        doc.setTextColor(0);
        doc.setFontSize(9);
        doc.setFont(undefined, 'normal');
        doc.text(`${valor}`, xActual + barWidth / 2, yBase + 10, {
            align: 'center'
        });

        doc.setFontSize(10);
        doc.setFont(undefined, 'bold');
        doc.text(`${key}`, xActual + barWidth / 2, y + altura + 20, {
            align: 'center'
        });
        xActual += barWidth + spacing;
    });
}
